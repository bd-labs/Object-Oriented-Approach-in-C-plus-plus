//////////////////////////////////////////////////////////////////////////
// FileName:			Main.cpp
// Description:			Program to implement WordFont, using multi dimensional vectors and functions
// Author:				Bharath Darapu
// Project Purpose:     HomeWork5
// Project Name:		WordFont
//////////////////////////////////////////////////////////////////////////

#include<iostream>
#include "WordFont.h"   //Including the .h File

//Main method implementation
int main()
{
	WordFont wf_obj;    // WordFont object declaration
    wf_obj.Word_Font(); //call to the function Word_Font
	//_getch();
	return 0;
}